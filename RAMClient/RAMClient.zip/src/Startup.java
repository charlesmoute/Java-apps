import component.view.Navigator;

public class Startup {
	public static void main(String[] arg){
		new Navigator().setVisible(true);
	}
}
